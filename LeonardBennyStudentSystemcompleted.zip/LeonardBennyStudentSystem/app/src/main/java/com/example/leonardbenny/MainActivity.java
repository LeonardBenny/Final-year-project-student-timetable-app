package com.example.leonardbenny;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.OAuthProvider;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        auth= FirebaseAuth.getInstance();
    }

    public void onClickLogin (View view)
    {
        // https://firebase.google.com/docs/auth/android/microsoft-oauth

        OAuthProvider.Builder provider=OAuthProvider.newBuilder("microsoft.com");
        provider.addCustomParameter("prompt" , "select_account");


        List<String> arrayList=new ArrayList<String>() ;
        arrayList.add("mail.read");
        arrayList.add("calendars.read");
        provider.setScopes(arrayList);
        Task<AuthResult> pendingResultTask=auth.getPendingAuthResult();
        if (pendingResultTask != null)
        {
            pendingResultTask.addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete (@NonNull @NotNull Task<AuthResult> task)
                {
                    if(task.isSuccessful())
                    {
                        gotoMainClass();
                    }
                    else
                    {
                        Snackbar.make(findViewById(android.R.id.content),"Failed to Login",Snackbar.LENGTH_LONG).show();
                    }
                }
            });

        }
        else
        {

            auth.startActivityForSignInWithProvider(this , provider.build()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete (@NonNull @org.jetbrains.annotations.NotNull Task<AuthResult> task) {

                    if(task.isSuccessful())
                    {
                        gotoMainClass();
                    }
                    else
                    {
                        Snackbar.make(findViewById(android.R.id.content),"Failed to Login",Snackbar.LENGTH_LONG).show();
                    }
                }
            });

        }
    }

    private void gotoMainClass ()
    {

        Intent myIntent = new Intent(MainActivity.this,HomeActivity.class);
        startActivity(myIntent);
    }
}