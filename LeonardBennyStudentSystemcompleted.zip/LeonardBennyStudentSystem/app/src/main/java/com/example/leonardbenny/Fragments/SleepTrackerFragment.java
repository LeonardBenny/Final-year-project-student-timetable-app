package com.example.leonardbenny.Fragments;

import android.os.Bundle;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Chronometer;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.leonardbenny.R;

public class SleepTrackerFragment extends Fragment implements View.OnClickListener {
    private Chronometer chronometer;
    private boolean running;
    private long aLong;
    Button btnStart;
    Button btnEnd;
    Button btnReset;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_sleeptracker, container, false);


        chronometer = view.findViewById(R.id.chronometer);
        chronometer.setFormat ("My Sleep Timer : %s");

        btnStart = view.findViewById(R.id.btnStart);
        btnEnd= view.findViewById(R.id.btnEnd);
        btnReset= view.findViewById(R.id.btnReset);

        btnStart.setOnClickListener(this);
        btnEnd.setOnClickListener(this);
        btnReset.setOnClickListener(this);


        return view;
    }


    @Override
    public void onClick (View v)
    {

        if(v==btnStart)
        {

            if (!running) {
                chronometer.setBase(SystemClock.elapsedRealtime()-aLong);
                chronometer.start();
                running = true;
            }

        }
        if(v==btnEnd)
        {
            if (running) {
                chronometer.stop();
                aLong=SystemClock. elapsedRealtime()-chronometer.getBase();
                running = false;
            }

        }
        if(v==btnReset)
        {

            chronometer.setBase(SystemClock.elapsedRealtime());
            aLong= 0;
        }

    }
}